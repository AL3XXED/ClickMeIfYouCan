﻿namespace ClickMe.Models;

internal class Spieler
{
    public string SpielerName { get; set; }
    public int Punktzahl { get; set; }
}
