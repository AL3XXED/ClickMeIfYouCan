namespace ClickMe.Views;

public partial class Optionen : ContentPage
{
	public Optionen()
	{
		InitializeComponent();
	}
}